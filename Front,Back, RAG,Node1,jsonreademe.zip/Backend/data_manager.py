import json
import os
import pandas as pd
from typing import List, Dict, Any, Optional

class DataManager:
    def __init__(self, data_path: str = "data.json", base_data_dir: Optional[str] = None):
        self.data_path = data_path
        self.base_data_dir = base_data_dir
        self.data = self._load_data()

    def _load_data(self) -> Dict[str, List[Dict[str, Any]]]:
        session_data = {}
        if os.path.exists(self.data_path):
            try:
                with open(self.data_path, "r") as f:
                    session_data = json.load(f)
            except Exception as e:
                print(f"Error loading session data: {e}")

        # Load external data if base_data_dir is provided
        external_data = {}
        if self.base_data_dir and os.path.exists(self.base_data_dir):
            external_data = self._load_from_external_files()

        # Merge data: External data takes initial priority, but session data (updates/adds) overrides it
        # Actually, for the first run, external data is the source. 
        # If we already have session data, we might want to keep it if it contains edits.
        # However, the user request says "refer the data from this path", implying it should refresh.
        # Let's combine them: External data fills the categories, session data holds modifications.
        
        final_data = self._get_initial_data() # Fallback
        
        if external_data:
            for cat, records in external_data.items():
                final_data[cat] = records
        
        # Overlay session data (which might contain edits/deletes done via the UI)
        if session_data:
            for cat, records in session_data.items():
                if records: # Only override if there's actually data
                    final_data[cat] = records

        return final_data

    def _load_from_external_files(self) -> Dict[str, List[Dict[str, Any]]]:
        external_data = {}
        if not self.base_data_dir:
            return external_data

        mapping = {
            "Onboarding.xlsx": "onboarding",
            "Offboarding.xlsx": "offboarding",
            "Invoice.xlsx": "invoice",
            "Variance.xlsx": "variance",
            "Policy.txt": "policy", # Or Policies.txt
            "Policies.txt": "policy",
            "Onboarding.txt": "onboarding",
            "Offboarding.txt": "offboarding",
            "Variance.txt": "variance"
        }

        for filename in os.listdir(self.base_data_dir):
            if filename in mapping:
                category = mapping[filename]
                file_path = os.path.join(self.base_data_dir, filename)
                
                try:
                    if filename.endswith('.xlsx'):
                        df = pd.read_excel(file_path)
                        # Clean column names (strip spaces, etc.)
                        df.columns = [c.strip() for c in df.columns]
                        records = df.to_dict(orient='records')
                        # Ensure no NaN values in records
                        clean_records = []
                        for r in records:
                            clean_r = {k: (None if pd.isna(v) else v) for k, v in r.items()}
                            clean_records.append(clean_r)
                        external_data[category] = clean_records
                    elif filename.endswith('.txt'):
                        # For text files, we don't have a standard format, but we'll try to read it as a record if it looks like one,
                        # or just as a single record with 'content' field.
                        # However, for the application tables, they expect lists of dicts.
                        with open(file_path, 'r') as f:
                            content = f.read()
                            if content.strip():
                                if category not in external_data:
                                    external_data[category] = []
                                external_data[category].append({"content": content, "source": filename})
                except Exception as e:
                    print(f"Error processing {filename}: {e}")

        return external_data

    def _save_data(self, data: Optional[Dict[str, List[Dict[str, Any]]]] = None):
        if data is None:
            data = self.data
        try:
            with open(self.data_path, "w") as f:
                json.dump(data, f, indent=2)
        except Exception as e:
            print(f"Error saving data: {e}")

    def _save_to_external_file(self, category: str):
        if not self.base_data_dir or not os.path.exists(self.base_data_dir):
            return

        # Inverse mapping: category -> filename
        mapping = {
            "onboarding": "Onboarding.xlsx",
            "offboarding": "Offboarding.xlsx",
            "invoice": "Invoice.xlsx",
            "variance": "Variance.xlsx"
        }

        if category in mapping:
            filename = mapping[category]
            file_path = os.path.join(self.base_data_dir, filename)
            records = self.data.get(category, [])
            
            try:
                if records:
                    df = pd.DataFrame(records)
                    df.to_excel(file_path, index=False)
                    print(f"Successfully saved {category} to {file_path}")
            except Exception as e:
                print(f"Error saving {category} to external file: {e}")

    def _get_initial_data(self) -> Dict[str, List[Dict[str, Any]]]:
        # Pre-populating with mock data provided by the user
        return {
            "onboarding": [],
            "offboarding": [],
            "invoice": [],
            "variance": [],
            "policy": [],
            "newOnboardingDocs": []
        }

    def get_records(self, category: str) -> List[Dict[str, Any]]:
        return self.data.get(category, [])

    def add_record(self, category: str, record: Dict[str, Any], sync_external: bool = True):
        if category not in self.data:
            self.data[category] = []
        self.data[category].append(record)
        self._save_data()
        if sync_external:
            self._save_to_external_file(category)

    def delete_record(self, category: str, field: str, value: Any, sync_external: bool = True):
        if category in self.data:
            self.data[category] = [r for r in self.data[category] if r.get(field) != value]
            self._save_data()
            if sync_external:
                self._save_to_external_file(category)

    def update_record(self, category: str, field: str, value: Any, updated_record: Dict[str, Any], sync_external: bool = True):
        if category in self.data:
            for i, r in enumerate(self.data[category]):
                if r.get(field) == value:
                    self.data[category][i] = updated_record
                    break
            self._save_data()
            if sync_external:
                self._save_to_external_file(category)
