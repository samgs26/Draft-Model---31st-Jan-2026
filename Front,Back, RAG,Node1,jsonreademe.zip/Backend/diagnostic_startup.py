import os
from dotenv import load_dotenv
load_dotenv()

print("Initializing RAGEngine...")
from rag_engine import RAGEngine
try:
    rag_engine = RAGEngine()
    print("RAGEngine initialized successfully.")
except Exception as e:
    print(f"Error initializing RAGEngine: {e}")
    import traceback
    traceback.print_exc()

print("Initializing DataManager...")
from data_manager import DataManager
try:
    base_data_dir = os.getenv("BASE_DATA_DIR")
    data_manager = DataManager(base_data_dir=base_data_dir)
    print("DataManager initialized successfully.")
except Exception as e:
    print(f"Error initializing DataManager: {e}")
    import traceback
    traceback.print_exc()

print("Initializing Agents...")
from agents import (
    AdminAgent, UserAgent, OnboardingAgent, OffboardingAgent, 
    InvoiceAgent, VarianceAgent, PolicyAgent, NewOnboardingDocsAgent
)
try:
    agents = {
        "admin": AdminAgent(rag_engine),
        "user": UserAgent(rag_engine),
        "onboarding": OnboardingAgent(rag_engine),
        "offboarding": OffboardingAgent(rag_engine),
        "invoice": InvoiceAgent(rag_engine),
        "variance": VarianceAgent(rag_engine),
        "policy": PolicyAgent(rag_engine),
        "newOnboardingDocs": NewOnboardingDocsAgent(rag_engine)
    }
    print("Agents initialized successfully.")
except Exception as e:
    print(f"Error initializing Agents: {e}")
    import traceback
    traceback.print_exc()

print("Checking BASE_DATA_DIR indexing...")
if base_data_dir and os.path.exists(base_data_dir):
    print(f"Indexing files from {base_data_dir}...")
    for filename in os.listdir(base_data_dir):
        if filename.startswith('~$'):
            continue
        if filename.endswith(('.pdf', '.docx', '.txt', '.xlsx', '.xls')):
            file_path = os.path.join(base_data_dir, filename)
            try:
                rag_engine.add_documents(file_path)
                print(f"Indexed {filename}")
            except Exception as e:
                print(f"Error indexing {filename}: {e}")
                import traceback
                traceback.print_exc()
