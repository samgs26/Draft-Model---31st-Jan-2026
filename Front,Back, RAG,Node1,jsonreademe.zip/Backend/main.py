from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import os
import shutil
from dotenv import load_dotenv
from fastapi_mail import FastMail, MessageSchema, ConnectionConfig, MessageType

# Load environment variables from .env file
load_dotenv()

from rag_engine import RAGEngine
from agents import (
    AdminAgent, UserAgent, OnboardingAgent, OffboardingAgent, 
    InvoiceAgent, VarianceAgent, PolicyAgent, NewOnboardingDocsAgent,
    data_manager
)

app = FastAPI(title="HR RAG AI Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize RAG Engine and Agents
rag_engine = RAGEngine()
base_data_dir = os.getenv("BASE_DATA_DIR")
if base_data_dir and os.path.exists(base_data_dir):
    print(f"Indexing files from {base_data_dir}...")
    for filename in os.listdir(base_data_dir):
        if filename.startswith('~$'):
            continue
        if filename.endswith(('.pdf', '.docx', '.txt', '.xlsx', '.xls')):
            file_path = os.path.join(base_data_dir, filename)
            try:
                rag_engine.add_documents(file_path)
            except Exception as e:
                print(f"Error indexing {filename}: {e}")

agents = {
    "admin": AdminAgent(rag_engine),
    "user": UserAgent(rag_engine),
    "onboarding": OnboardingAgent(rag_engine),
    "offboarding": OffboardingAgent(rag_engine),
    "invoice": InvoiceAgent(rag_engine),
    "variance": VarianceAgent(rag_engine),
    "policy": PolicyAgent(rag_engine),
    "newOnboardingDocs": NewOnboardingDocsAgent(rag_engine)
}

UPLOAD_DIR = os.getenv("UPLOAD_DIR", "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

# SMTP Configuration
conf = ConnectionConfig(
    MAIL_USERNAME=os.getenv("MAIL_USERNAME"),
    MAIL_PASSWORD=os.getenv("MAIL_PASSWORD"),
    MAIL_FROM=os.getenv("MAIL_FROM"),
    MAIL_PORT=int(os.getenv("MAIL_PORT", 587)),
    MAIL_SERVER=os.getenv("MAIL_SERVER"),
    MAIL_FROM_NAME=os.getenv("MAIL_FROM_NAME"),
    MAIL_STARTTLS=True,
    MAIL_SSL_TLS=False,
    USE_CREDENTIALS=True,
    VALIDATE_CERTS=True
)

class ChatRequest(BaseModel):
    message: str
    role: str # 'admin' or 'user'
    category: Optional[str] = None # specific agent category
    mockData: Optional[dict] = None

class ChatResponse(BaseModel):
    response: str

class EmailRequest(BaseModel):
    recipients: List[str]
    subject: str
    message: str

@app.post("/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    try:
        # Use specific category agent if provided, else fallback to role agent
        agent_key = request.category if request.category in agents else request.role
        agent = agents.get(agent_key, agents["user"])
        
        response = agent.chat(request.message)
        return ChatResponse(response=response)
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/records/{category}")
async def get_records(category: str):
    return data_manager.get_records(category)

@app.post("/records/{category}")
async def add_record(category: str, record: Dict[str, Any]):
    data_manager.add_record(category, record)
    return {"status": "success"}

@app.delete("/records/{category}/{field}/{value}")
async def delete_record(category: str, field: str, value: str):
    data_manager.delete_record(category, field, value)
    return {"status": "success"}

@app.post("/send-email")
async def send_email(request: EmailRequest):
    try:
        message = MessageSchema(
            subject=request.subject,
            recipients=request.recipients,
            body=request.message,
            subtype=MessageType.html
        )
        
        fm = FastMail(conf)
        await fm.send_message(message)
        return {"message": "Email has been sent"}
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Failed to send email: {str(e)}")

@app.post("/upload")
async def upload_file(file: UploadFile = File(...), category: Optional[str] = Form(None)):
    try:
        file_path = os.path.join(UPLOAD_DIR, file.filename)
        with open(file_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
        
        # Add to RAG Engine
        num_chunks, preview_data, columns, full_text = rag_engine.add_documents(file_path)
        
        # If it's an Excel file and a category is provided, update DataManager
        if file.filename.endswith(('.xlsx', '.xls')) and category:
            df = pd.read_excel(file_path)
            df.columns = [c.strip() for c in df.columns]
            records = df.to_dict(orient='records')
            clean_records = []
            for r in records:
                clean_r = {k: (None if pd.isna(v) else v) for k, v in r.items()}
                clean_records.append(clean_r)
            
            # Update internal data
            data_manager.data[category] = clean_records
            data_manager._save_data()
            # Also sync to BASE_DATA_DIR (which overwrites the existing file there with the new one we just uploaded)
            data_manager._save_to_external_file(category)

        return {
            "filename": file.filename, 
            "chunks": num_chunks, 
            "status": "indexed",
            "preview": preview_data,
            "columns": columns,
            "full_text": full_text
        }
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/health")
async def health_check():
    return {"status": "healthy"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
