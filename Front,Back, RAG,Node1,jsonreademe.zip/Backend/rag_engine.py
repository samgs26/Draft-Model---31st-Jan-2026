import os
from typing import List
from langchain_community.document_loaders import PyPDFLoader, TextLoader, Docx2txtLoader
from langchain_text_splitters import RecursiveCharacterTextSplitter
from langchain_openai import OpenAIEmbeddings
from langchain_community.vectorstores import FAISS
from langchain_core.documents import Document
import pandas as pd

class RAGEngine:
    def __init__(self, index_path=None):
        self.index_path = index_path or os.getenv("INDEX_PATH", "faiss_index")
        api_key = os.getenv("OPENAI_API_KEY")
        # For OpenRouter, we should provide the base_url and potentially a specific model
        self.embeddings = OpenAIEmbeddings(
            openai_api_key=api_key,
            base_url="https://openrouter.ai/api/v1",
            model="openai/text-embedding-3-small" # Common embedding model on OpenRouter
        )
        self.vector_store = None
        self.load_index()

    def load_index(self):
        if os.path.exists(self.index_path):
            self.vector_store = FAISS.load_local(self.index_path, self.embeddings, allow_dangerous_deserialization=True)
            print("Loaded existing FAISS index.")
        else:
            print("No existing FAISS index found.")

    def add_documents(self, file_path: str):
        if file_path.endswith('.pdf'):
            loader = PyPDFLoader(file_path)
        elif file_path.endswith('.txt'):
            loader = TextLoader(file_path)
        elif file_path.endswith('.docx'):
            loader = Docx2txtLoader(file_path)
        elif file_path.endswith(('.xlsx', '.xls')):
            # Using pandas for better structured data handling
            df = pd.read_excel(file_path)
            documents = []
            full_text_list = []
            for _, row in df.iterrows():
                content = ", ".join([f"{col}: {val}" for col, val in row.items() if pd.notna(val)])
                documents.append(Document(page_content=content, metadata={"source": file_path, "type": "excel_row"}))
                full_text_list.append(content)
            
            full_text = "\n".join(full_text_list)
            
            if self.vector_store:
                self.vector_store.add_documents(documents)
            else:
                self.vector_store = FAISS.from_documents(documents, self.embeddings)
            
            self.vector_store.save_local(self.index_path)
            return len(documents), df.head(10).to_dict(orient='records'), df.columns.tolist(), full_text
        else:
            raise ValueError(f"Unsupported file type: {file_path}")

        documents = loader.load()
        full_text = "\n".join([doc.page_content for doc in documents])
        text_splitter = RecursiveCharacterTextSplitter(chunk_size=1000, chunk_overlap=200)
        chunks = text_splitter.split_documents(documents)

        if self.vector_store:
            self.vector_store.add_documents(chunks)
        else:
            self.vector_store = FAISS.from_documents(chunks, self.embeddings)
        
        self.vector_store.save_local(self.index_path)
        return len(chunks), None, None, full_text

    def query(self, text: str, k: int = 4) -> List[Document]:
        if not self.vector_store:
            return []
        return self.vector_store.similarity_search(text, k=k)
