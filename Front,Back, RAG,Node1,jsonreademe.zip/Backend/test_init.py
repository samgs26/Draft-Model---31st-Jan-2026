import os
from dotenv import load_dotenv
load_dotenv()

from rag_engine import RAGEngine
from agents import AdminAgent, UserAgent

print("Starting test...")
try:
    rag = RAGEngine()
    print("RAGEngine initialized.")
    admin = AdminAgent(rag)
    print("AdminAgent initialized.")
    user = UserAgent(rag)
    print("UserAgent initialized.")
except Exception as e:
    import traceback
    traceback.print_exc()
