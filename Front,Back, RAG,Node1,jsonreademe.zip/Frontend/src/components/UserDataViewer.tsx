import { useState, useEffect } from 'react';
import { Plus, X, Loader2, Table, Edit2, Trash2 } from 'lucide-react';
import { DataTable } from './DataTable';
import { getRecords, addRecord, deleteRecord } from '../services/api';

interface UserDataViewerProps {
    category: string;
    refreshTrigger?: number;
}

export function UserDataViewer({ category, refreshTrigger }: UserDataViewerProps) {
    const [data, setData] = useState<any[]>([]);
    const [loading, setLoading] = useState(false);
    const [isAddModalOpen, setIsAddModalOpen] = useState(false);
    const [newRecord, setNewRecord] = useState<any>({});
    const [editingRecord, setEditingRecord] = useState<any>(null);

    const columns = data.length > 0 ? Object.keys(data[0]) : [];

    const fetchRecords = async () => {
        setLoading(true);
        try {
            const records = await getRecords(category);
            setData(records);
        } catch (error) {
            console.error('Failed to fetch records:', error);
        } finally {
            setLoading(false);
        }
    };

    useEffect(() => {
        fetchRecords();
    }, [category, refreshTrigger]);

    const handleAddRecord = async () => {
        const recordToAdd = { ...newRecord };

        // Simple id generation if missing
        if (!recordToAdd.id && !recordToAdd.invoiceNumber && !recordToAdd.policyId && !recordToAdd.projectId && !recordToAdd.docId) {
            recordToAdd.id = `NEW-${Date.now()}`;
        }

        try {
            await addRecord(category, recordToAdd);
            await fetchRecords();
            setNewRecord({});
            setIsAddModalOpen(false);
        } catch (error) {
            alert('Failed to add record');
        }
    };

    const handleDeleteRecord = async (index: number) => {
        if (confirm('Are you sure you want to delete this record?')) {
            const record = data[index];
            const lookupField = record.id ? 'id' :
                record.invoiceNumber ? 'invoiceNumber' :
                    record.policyId ? 'policyId' :
                        record.projectId ? 'projectId' :
                            record.docId ? 'docId' : null;

            if (!lookupField) {
                alert('Cannot delete record: No unique identifier found');
                return;
            }

            try {
                await deleteRecord(category, lookupField, record[lookupField]);
                await fetchRecords();
            } catch (error) {
                alert('Failed to delete record');
            }
        }
    };

    const handleEditRecord = (index: number) => {
        setEditingRecord({ ...data[index], index });
        setIsAddModalOpen(true);
    };

    const handleUpdateRecord = async () => {
        if (editingRecord) {
            const updatedRecord = { ...editingRecord };
            delete updatedRecord.index;

            try {
                const lookupField = updatedRecord.id ? 'id' :
                    updatedRecord.invoiceNumber ? 'invoiceNumber' :
                        updatedRecord.policyId ? 'policyId' :
                            updatedRecord.projectId ? 'projectId' :
                                updatedRecord.docId ? 'docId' : null;

                if (lookupField) {
                    await deleteRecord(category, lookupField, updatedRecord[lookupField]);
                }
                await addRecord(category, updatedRecord);
                await fetchRecords();
                setEditingRecord(null);
                setIsAddModalOpen(false);
            } catch (error) {
                alert('Failed to update record');
            }
        }
    };

    const formatColumnName = (column: string) => {
        return column
            .replace(/([A-Z])/g, ' $1')
            .replace(/^./, (str) => str.toUpperCase())
            .trim();
    };

    return (
        <div className="space-y-4">
            <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                    <div className="p-2 bg-teal-100 rounded-lg">
                        <Table className="size-5 text-teal-600" />
                    </div>
                    <h3 className="text-lg font-bold text-gray-800">Tabular View</h3>
                </div>
                {loading && <Loader2 className="size-5 text-teal-600 animate-spin" />}
            </div>

            {/* Total Records and Add Button - Added below Header 3 */}
            <div className="mb-6 flex justify-between items-center">
                <div className="flex items-center gap-4">
                    <div className="px-4 py-2 bg-gradient-to-r from-teal-50 to-blue-50 rounded-lg border border-teal-200">
                        <p className="text-sm text-teal-700">
                            Total Records: <span className="font-bold text-lg">{data.length}</span>
                        </p>
                    </div>
                </div>
                {['onboarding', 'offboarding', 'invoice', 'variance'].includes(category) && (
                    <button
                        onClick={() => {
                            setEditingRecord(null);
                            setNewRecord({});
                            setIsAddModalOpen(true);
                        }}
                        className="flex items-center gap-2 px-5 py-2.5 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg hover:from-teal-700 hover:to-blue-700 transition-all font-medium shadow-lg hover:shadow-xl transform hover:scale-105"
                    >
                        <Plus className="size-5" />
                        Add New Record
                    </button>
                )}
            </div>

            <div className="bg-white rounded-xl shadow-inner border border-teal-50 overflow-hidden">
                <DataTable
                    data={data}
                    reportType={category}
                    onEdit={handleEditRecord}
                    onDelete={handleDeleteRecord}
                    variant="teal"
                />
            </div>

            {!loading && data.length === 0 && (
                <div className="text-center py-8 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                    <p className="text-gray-500">No records found for this section.</p>
                </div>
            )}

            {/* Add Record Modal */}
            {isAddModalOpen && (
                <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
                    <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-teal-100">
                        <div className="sticky top-0 bg-gradient-to-r from-teal-600 to-blue-600 px-6 py-5 flex items-center justify-between">
                            <h3 className="text-xl text-white font-bold">
                                {editingRecord ? '✏️ Edit Record' : '➕ Add New Record'}
                            </h3>
                            <button
                                onClick={() => {
                                    setIsAddModalOpen(false);
                                    setEditingRecord(null);
                                    setNewRecord({});
                                }}
                                className="p-2 hover:bg-white/20 rounded-lg transition-colors"
                            >
                                <X className="size-5 text-white" />
                            </button>
                        </div>

                        <div className="p-6">
                            <div className="space-y-4">
                                {columns.map((column) => (
                                    <div key={column}>
                                        <label className="block text-sm text-gray-700 mb-2 font-medium">
                                            {formatColumnName(column)}
                                        </label>
                                        <input
                                            type="text"
                                            value={editingRecord ? editingRecord[column] || '' : newRecord[column] || ''}
                                            onChange={(e) => {
                                                if (editingRecord) {
                                                    setEditingRecord({ ...editingRecord, [column]: e.target.value });
                                                } else {
                                                    setNewRecord({ ...newRecord, [column]: e.target.value });
                                                }
                                            }}
                                            className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500 focus:border-transparent transition-all"
                                            placeholder={`Enter ${formatColumnName(column)}`}
                                        />
                                    </div>
                                ))}
                            </div>

                            <div className="mt-8 flex gap-3 justify-end">
                                <button
                                    onClick={() => {
                                        setIsAddModalOpen(false);
                                        setEditingRecord(null);
                                        setNewRecord({});
                                    }}
                                    className="px-6 py-2.5 border-2 border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-all font-medium"
                                >
                                    Cancel
                                </button>
                                <button
                                    onClick={editingRecord ? handleUpdateRecord : handleAddRecord}
                                    className="px-6 py-2.5 bg-gradient-to-r from-teal-600 to-blue-600 text-white rounded-lg hover:from-teal-700 hover:to-blue-700 transition-all font-medium shadow-lg"
                                >
                                    {editingRecord ? 'Update Record' : 'Add Record'}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
}
