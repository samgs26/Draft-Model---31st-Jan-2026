# `react-aspect-ratio`

View docs [here](https://radix-ui.com/primitives/docs/utilities/aspect-ratio).
