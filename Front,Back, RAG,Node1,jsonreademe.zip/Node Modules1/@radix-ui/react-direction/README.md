# `react-direction`

## Installation

```sh
$ yarn add @radix-ui/react-direction
# or
$ npm install @radix-ui/react-direction
```

## Usage

View docs [here](https://radix-ui.com/primitives/docs/utilities/direction).
