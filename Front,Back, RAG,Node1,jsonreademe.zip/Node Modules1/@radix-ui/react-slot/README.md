# `react-slot`

View docs [here](https://radix-ui.com/primitives/docs/utilities/slot).
