# `react-use-callback-ref`

## Installation

```sh
$ yarn add @radix-ui/react-use-callback-ref
# or
$ npm install @radix-ui/react-use-callback-ref
```

## Usage

This is an internal utility, not intended for public usage.
