# `react-use-is-hydrated`

## Usage

This is an internal utility, not intended for public usage.
