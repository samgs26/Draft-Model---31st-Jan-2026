# `react-use-size`

## Installation

```sh
$ yarn add @radix-ui/react-use-size
# or
$ npm install @radix-ui/react-use-size
```

## Usage

This is an internal utility, not intended for public usage.
