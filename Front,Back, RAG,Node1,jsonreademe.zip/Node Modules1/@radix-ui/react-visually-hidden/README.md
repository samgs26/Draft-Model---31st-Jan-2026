# `react-visually-hidden`

View docs [here](https://radix-ui.com/primitives/docs/utilities/visually-hidden).
