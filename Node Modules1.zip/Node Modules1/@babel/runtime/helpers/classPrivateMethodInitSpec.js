var checkPrivateRedeclaration = require("./checkPrivateRedeclaration.js");
function _classPrivateMethodInitSpec(e, a) {
  checkPrivateRedeclaration(e, a), a.add(e);
}
module.exports = _classPrivateMethodInitSpec, module.exports.__esModule = true, module.exports["default"] = module.exports;