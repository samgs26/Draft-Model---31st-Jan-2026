# @floating-ui/core

This is the platform-agnostic core of Floating UI, exposing the main
`computePosition` function but no platform interface logic.
