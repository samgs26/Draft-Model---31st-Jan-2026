# `react-accordion`

View docs [here](https://radix-ui.com/primitives/docs/components/accordion).
