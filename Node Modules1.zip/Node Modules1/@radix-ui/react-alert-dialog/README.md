# `react-alert-dialog`

View docs [here](https://radix-ui.com/primitives/docs/components/alert-dialog).
