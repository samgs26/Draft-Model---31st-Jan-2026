# `react-scroll-area`

View docs [here](https://radix-ui.com/primitives/docs/components/scroll-area).
