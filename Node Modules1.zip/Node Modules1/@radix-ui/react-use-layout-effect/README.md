# `react-use-layout-effect`

## Installation

```sh
$ yarn add @radix-ui/react-use-layout-effect
# or
$ npm install @radix-ui/react-use-layout-effect
```

## Usage

This is an internal utility, not intended for public usage.
