# `react-use-previous`

## Installation

```sh
$ yarn add @radix-ui/react-use-previous
# or
$ npm install @radix-ui/react-use-previous
```

## Usage

This is an internal utility, not intended for public usage.
