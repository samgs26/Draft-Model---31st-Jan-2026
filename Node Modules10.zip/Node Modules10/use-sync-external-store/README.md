# use-sync-external-store

Backwards-compatible shim for [`React.useSyncExternalStore`](https://reactjs.org/docs/hooks-reference.html#usesyncexternalstore). Works with any React that supports Hooks.

See also https://github.com/reactwg/react-18/discussions/86.
