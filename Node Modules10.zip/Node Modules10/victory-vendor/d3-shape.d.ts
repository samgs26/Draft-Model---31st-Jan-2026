
// `victory-vendor/d3-shape` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-shape";
