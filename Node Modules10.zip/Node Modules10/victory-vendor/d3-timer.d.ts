
// `victory-vendor/d3-timer` (TypeScript)
//
// Export the type definitions for this package:
export * from "d3-timer";
