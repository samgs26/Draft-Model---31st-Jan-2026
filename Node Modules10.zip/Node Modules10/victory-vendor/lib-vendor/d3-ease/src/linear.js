"use strict";

Object.defineProperty(exports, "__esModule", {
  value: true
});
exports.linear = void 0;

const linear = t => +t;

exports.linear = linear;