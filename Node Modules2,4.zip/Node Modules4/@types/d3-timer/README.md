# Installation
> `npm install --save @types/d3-timer`

# Summary
This package contains type definitions for d3-timer (https://github.com/d3/d3-timer/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-timer.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:37 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), and [Nathan Bierema](https://github.com/Methuselah96).
