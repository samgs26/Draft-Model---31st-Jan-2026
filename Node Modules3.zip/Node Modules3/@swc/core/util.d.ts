export declare function wrapNativeSuper(Class: any): never;
