# @swc/types

Typings for `@swc/core` APIs. This is a separate package because SWC is used by various tools but not all of them want to depend on `@swc/core`.
This package is very cheap, so feel free to depend on this.
