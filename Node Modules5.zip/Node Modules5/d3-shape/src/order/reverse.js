import none from "./none.js";

export default function(series) {
  return none(series).reverse();
}
