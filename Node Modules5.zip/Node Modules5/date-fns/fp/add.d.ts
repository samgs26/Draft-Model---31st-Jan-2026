export declare const add: import("./types.js").FPFn2<
  Date,
  import("../fp.js").Duration,
  string | number | Date
>;
