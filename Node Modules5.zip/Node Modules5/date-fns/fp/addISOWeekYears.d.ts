export declare const addISOWeekYears: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
