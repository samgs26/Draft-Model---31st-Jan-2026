export declare const addMinutes: import("./types.js").FPFn2<
  Date,
  number,
  string | number | Date
>;
