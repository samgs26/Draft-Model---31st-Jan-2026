// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { addSeconds as fn } from "../addSeconds.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const addSeconds = convertToFP(fn, 2);

// Fallback for modularized imports:
export default addSeconds;
