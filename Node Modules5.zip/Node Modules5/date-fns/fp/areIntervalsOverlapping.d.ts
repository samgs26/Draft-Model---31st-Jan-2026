export declare const areIntervalsOverlapping: import("./types.js").FPFn2<
  boolean,
  import("../fp.js").Interval<Date>,
  import("../fp.js").Interval<Date>
>;
