// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { closestIndexTo as fn } from "../closestIndexTo.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const closestIndexTo = convertToFP(fn, 2);

// Fallback for modularized imports:
export default closestIndexTo;
