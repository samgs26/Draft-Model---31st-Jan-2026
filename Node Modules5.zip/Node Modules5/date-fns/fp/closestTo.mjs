// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { closestTo as fn } from "../closestTo.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const closestTo = convertToFP(fn, 2);

// Fallback for modularized imports:
export default closestTo;
