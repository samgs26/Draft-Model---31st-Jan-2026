"use strict";
exports.compareDesc = void 0;

var _index = require("../compareDesc.js");
var _index2 = require("./_lib/convertToFP.js"); // This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.

const compareDesc = (exports.compareDesc = (0, _index2.convertToFP)(
  _index.compareDesc,
  2,
));
