// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { daysToWeeks as fn } from "../daysToWeeks.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const daysToWeeks = convertToFP(fn, 1);

// Fallback for modularized imports:
export default daysToWeeks;
