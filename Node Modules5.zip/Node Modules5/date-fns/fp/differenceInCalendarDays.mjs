// This file is generated automatically by `scripts/build/fp.ts`. Please, don't change it.
import { differenceInCalendarDays as fn } from "../differenceInCalendarDays.mjs";
import { convertToFP } from "./_lib/convertToFP.mjs";

export const differenceInCalendarDays = convertToFP(fn, 2);

// Fallback for modularized imports:
export default differenceInCalendarDays;
