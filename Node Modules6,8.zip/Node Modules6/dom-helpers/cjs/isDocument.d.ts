export default function isDocument(element: Element | Document | Window): element is Document;
