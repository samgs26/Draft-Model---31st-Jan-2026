/**
 * Removes a given node from the DOM.
 *
 * @param node the node to remove
 */
export default function remove(node: Node | null): Node | null;
